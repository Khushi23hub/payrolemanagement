# payrolemanagementsystem

A Pen created on CodePen.io. Original URL: [https://codepen.io/khushicode23/pen/WNBzJzP](https://codepen.io/khushicode23/pen/WNBzJzP).

